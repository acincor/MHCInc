import subprocess
import requests
class module:
	def main():
		from MHCInc import copyright
		copyright.copyright_Swift()
	def caterpillar():
		from MHCInc import caterpillar
	def 单词九连猜():
		from MHCInc import 单词九连猜
	def nineWordGuessing():
		from MHCInc import 单词九连猜
	def 加密消息():
		from MHCInc import 加密消息
	def secretMessage():
		from MHCInc import 加密消息
	def snap():
		from MHCInc import 快照抓拍
	def 快照抓拍():
		from MHCInc import 快照抓拍
	def 螺旋万花筒():
		from MHCInc import 螺旋万花筒
	def spiralKaleidoscope():
		from MHCInc import 螺旋万花筒
	def 星光夜空():
		from MHCInc import 星光夜空
	def starlightNight():
		from MHCInc import 星光夜空
	def 圆筒万花筒():
		from MHCInc import 圆筒万花筒
	def cylinderKaleidoscope():
		from MHCInc import 圆筒万花筒
	def animal_guess():
		from MHCInc import animal_guess
	def caterpillar2():
		from MHCInc import caterpillar2
	def copyright():
		from MHCInc import copyright
	def eggCatcherPerfect():
		from MHCInc import egg_catcher_perfect
	def eggCatcher():
		from MHCInc import egg_catcher
	def GuessGame():
		from MHCInc import GuessGame
	def GuessGameEasy():
		from MHCInc import GuessGameEasy
	def GuessGameSecondary():
		from MHCInc import GuessGameSecondary
	def matchmaker():
		from MHCInc import matchmaker
	def MITLicense():
		from MHCInc import MITLicense
	def PHYSICAL_CONDITION_APPLET():
		from MHCInc import PHYSICAL_CONDITION_APPLET
	def Python3学习示例():
		from MHCInc import Python3学习示例
	from MHCInc import random
	def rectangle():
		from MHCInc import rectangle
	def robotBuilder():
		from MHCInc import robot_builder
	def screenPet():
		from MHCInc import screen_pet
	from MHCInc import swift

