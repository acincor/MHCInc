import random
def guessGame_1_10():
    number = random.randint(1,10)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_100():
    number = random.randint(1,100)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_1000():
    number = random.randint(1,1000)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_10000():
    number = random.randint(1,10000)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_100000():
    number = random.randint(1,100000)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_1000000():
    number = random.randint(1,1000000)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_10000000():
    number = random.randint(1,10000000)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_100000000():
    number = random.randint(1,100000000)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_1000000000():
    number = random.randint(1,10000000000)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_10000000000():
    number = random.randint(1,10000000000)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_100000000000():
    number = random.randint(1,100000000000)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_999999999999():
    number = random.randint(1,999999999999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_9():
    number = random.randint(1,9)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_99():
    number = random.randint(1,99)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_999():
    number = random.randint(1,999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_9999():
    number = random.randint(1,9999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_99999():
    number = random.randint(1,99999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_999999():
    number = random.randint(1,999999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_9999999():
    number = random.randint(1,9999999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_99999999():
    number = random.randint(1,99999999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_999999999():
    number = random.randint(1,999999999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_9999999999():
    number = random.randint(1,9999999999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
def guessGame_1_99999999999():
    number = random.randint(1,99999999999)

    guess = input('请输入你的数字:')

    if number == int(guess):
        print('太棒了，你猜对了!')
    else:
        print('sorry wrong,the collect int is: '+str(number))
